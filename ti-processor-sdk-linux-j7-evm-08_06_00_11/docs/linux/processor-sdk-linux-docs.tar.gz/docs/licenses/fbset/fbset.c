/*
 *  Linux Frame Buffer Device Configuration
 *
 *  � Copyright 1995-1999 by Geert Uytterhoeven
 *		       (Geert.Uytterhoeven@cs.kuleuven.ac.be)
 *
 *  --------------------------------------------------------------------------
 *
 *  This file is subject to the terms and conditions of the GNU General Public
 *  License. See the file COPYING in the main directory of the Linux
 *  distribution for more details.
 *
 *  Petr Vandrovec <vandrove@vc.cvut.cz>:
 *           -grayscale, -rgba, -nonstd, VGA modes reporting
 *
 *  Brad Midgley <brad@exodus.pht.com>:
 *           -match
 *
 */
